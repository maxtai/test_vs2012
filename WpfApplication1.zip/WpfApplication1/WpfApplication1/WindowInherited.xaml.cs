﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1
{
    /// <summary>
    /// WindowInherited.xaml 的交互逻辑
    /// </summary>
    public partial class WindowInherited : Window
    {
        public WindowInherited()
        {
            InitializeComponent();
        }

        private void Window_Loaded(object sender, RoutedEventArgs e)
        {
            List<int> fontSize=new List<int>();
            for (int i = 1; i <= 60; i++)
            {
                fontSize.Add(i);
            }

            drpWinFontSize.ItemsSource = fontSize;
            drpTxtFontSize.ItemsSource = fontSize;

        }

        private void btnFontSize_Click(object sender, RoutedEventArgs e)
        {
            this.FontSize = Convert.ToDouble(drpWinFontSize.SelectedItem);
        }

        private void btnTextBlock_Click(object sender, RoutedEventArgs e)
        {
            //textBlockInherited.FontSize = (double)((int)drpTxtFontSize.SelectedItem);
            textBlockInherited.FontSize =Convert.ToDouble (drpTxtFontSize.Text);
        }
    }
}
