﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Forms;

namespace WpfApplication1
{
    /// <summary>
    /// DataGrid_1.xaml 的交互逻辑
    /// </summary>
    public partial class DataGrid_1 : Window
    {
        public DataGrid_1()
        {
            InitializeComponent();
            Bind();
        }

        protected void Bind()
        {
            List<Province> proList = new List<Province>()
                {
                new Province(){proviceID="1", proviceName="北京",cityName="海淀"},
                new Province(){proviceID="2", proviceName="上海",cityName="浦东"},
                new Province(){proviceID="3", proviceName="浙江",cityName="杭州"},
                new Province(){proviceID="4", proviceName="江苏",cityName="南京"},
                new Province(){proviceID="5", proviceName="广东",cityName="广州"}
                };
            gridCitys.ItemsSource = proList;
            cboProvince.ItemsSource = proList;
            comobox_1.ItemsSource = proList;
            //comobox_1.get
            //textbox_1.au
            
        }

        public class Province
        {
            public string cityName { get; set; }
            public string proviceID { get; set; }
            public string proviceName { get; set; }
        }


    }
    
}
