﻿using System;
using System.Collections.Generic;
using System.Configuration;
using System.Data;
using System.Linq;
using System.Windows;

namespace WpfApplication1
{
    /// <summary>
    /// App.xaml 的交互逻辑
    /// </summary>
    public partial class App : Application
    {
        //[STAThread]
        //static void Main()
        //{
        //    Application app = new Application();
        //    app.StartupUri = new Uri("MainWindow.xaml", UriKind.Relative);
        //    app.ShutdownMode = ShutdownMode.OnExplicitShutdown;
        //    app.Run();
        //}



        private void Application_Actived_1(object sender, EventArgs e)
        {

        }

        private void Application_Exit_1(object sender, ExitEventArgs e)
        {

        }


    }
}
