﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;

namespace WpfApplication1.se
{
    /// <summary>
    /// TurnoverManager.xaml 的交互逻辑
    /// </summary>
    public class TurnoverManager : DependencyObject
    {
        public static double GetAngle(DependencyObject obj)
        {
            return (double)obj.GetValue(AngleProperty);
        }

        public static void SetAngle(DependencyObject obj,double values)
        {
            
            obj.SetValue(AngleProperty,values);
        }

        
        public static readonly DependencyProperty AngleProperty = DependencyProperty.RegisterAttached("Angle", typeof(double), typeof(TurnoverManager), new PropertyMetadata(0.0, OnAngleChanged));

        private static void OnAngleChanged(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {
            var element = (UIElement)d;
            if (element == null)
                return;
            element.RenderTransformOrigin = new Point(0.5,0.5);
            element.RenderTransform = new RotateTransform((double)e.NewValue);
           
        }        
    }

    public class Student:DependencyObject
    {
        public static readonly DependencyProperty nameProperty = DependencyProperty.Register("name", typeof(string), typeof(Student), new PropertyMetadata(OnValuedChange));
        public static readonly DependencyProperty ageProperty = DependencyProperty.Register("age", typeof(string), typeof(Student), new PropertyMetadata());
        public static readonly DependencyProperty birthdayProperty = DependencyProperty.Register("birthday", typeof(string), typeof(Student), new PropertyMetadata());
        public static readonly DependencyProperty countryProperty = DependencyProperty.Register("country", typeof(string), typeof(Student), new PropertyMetadata());

        public static void OnValuedChange(DependencyObject d, DependencyPropertyChangedEventArgs e)
        {

        }

        public string Name
        {
            get{return GetValue(nameProperty) as string;}
            set { SetValue(nameProperty, value); }            
        }
        public string Age
        {
            get { return GetValue(ageProperty) as string; }
            set { SetValue(ageProperty, value); }
        }
        public string Birthday
        {
            get { return GetValue(birthdayProperty) as string; }
            set { SetValue(birthdayProperty, value); }
        }
        public string Country
        {
            get { return GetValue(countryProperty) as string; }
            set { SetValue(countryProperty, value); }
        }

    }
}
