﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Windows;
using System.Windows.Controls;
using System.Windows.Data;
using System.Windows.Documents;
using System.Windows.Input;
using System.Windows.Media;
using System.Windows.Media.Imaging;
using System.Windows.Shapes;
using System.Windows.Threading;

namespace WpfApplication1
{
    /// <summary>
    /// WindowDepend.xaml 的交互逻辑
    /// </summary>
    public partial class WindowDepend : Window
    {
        public WindowDepend()
        {
            InitializeComponent();

            DispatcherTimer timer = new DispatcherTimer(TimeSpan.FromSeconds(1), DispatcherPriority.Normal, 
                (object sender, EventArgs e) =>
                {
                    int newValue = Counter == int.MaxValue ? 0 : Counter + 1;
                SetValue(counterKey, newValue);
                },Dispatcher
                );
        }

        public int Counter
        {
            get { return (int)GetValue(counterKey.DependencyProperty); }
        }

        private static readonly DependencyPropertyKey counterKey = DependencyProperty.RegisterReadOnly("Counter", typeof(int), typeof(WindowDepend), new PropertyMetadata(0));
    }
}
